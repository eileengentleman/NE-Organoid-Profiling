function [roiMasks] = MaskROI_multiple(image)
    figure; 
    imagesc(image); 
    axis image off; 
  
    uiwait(msgbox('Draw a region with left‐button'));

    hold on;
    roiHandles = {};    %cell array of imfreehand handles
    roiMasks   = {};    %cell array of binary masks
    roiPos     = {};    %cell array of [x,y] vertex lists

    count = 1;
    while true
        % 1) draw a freehand ROI
        h = imfreehand;   
        pos  = getPosition(h);
        % 2) Ask if we should keep or discard it
        choice = questdlg('Keep this ROI?','Confirm ROI','Yes','No','Yes');
        if strcmp(choice,'No')
            % User chose to delete it immediately:
            delete(h);
            % go back and let them redraw
            continue;
        end

        % 3) Otherwise, store the handle & its mask/position
        mask = createMask(h);
        roiHandles{count} = h;
        roiMasks  {count} = mask;
        roiPos    {count} = pos;

        % 4) Ask whether to draw another one
        another = questdlg('Draw another ROI?','Multiple ROIs','Yes','No','Yes');
        if strcmp(another,'No')
            break;
        end
        count = count + 1;
    end
    hold off;
end