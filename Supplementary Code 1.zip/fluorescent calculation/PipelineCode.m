addpath(genpath(pwd))
%% input image
I = imread('organoid.png');
if size(I,3)==3,  I = rgb2gray(I);  end

%% draw ROI
[roiMasks]=MaskROI_multiple(I);

%% line width
w=1000;
%% calcultae intensity
[I,means,positions]=Majorline_intensity(I,w,roiMasks);

%% plot mask and mean intensity
for i=1:size(roiMasks,2)
figure 
imagesc(roiMasks{i}); 
figure
plot(means{i});
end
