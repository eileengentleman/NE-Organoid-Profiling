function [I2,intensityPlots,arclengths]=Majorline_intensity(I,w,roiMasks)

numROIs          = numel(roiMasks);
centerlines      = cell(numROIs,1);    % will hold [xFull, yFull] for each ROI
arclengths       = cell(numROIs,1);    % will hold a column vector of cumulative arclength per ROI
intensityPlots   = cell(numROIs,1);    % will hold the width‐averaged intensity profile for each ROI

% 1) skeletonize binary image
for kk=1:numROIs
    ROImask=roiMasks{kk};
skel = bwskel(ROImask,'MinBranchLength',0);

% 2) isolate the skeleton of this ROI
skel = skel & ROImask;

% 3) find endpoints of the skeleton
endPts = bwmorph(skel,'endpoints');
[yE, xE] = find(endPts);
if numel(yE) < 2
    warning('ROI %d has fewer than 2 skeleton endpoints (found %d).', kk, numel(yE));
    continue;  
end
% 4) get all skeleton pixels and build a graph
[y, x] = find(skel);
idx    = sub2ind(size(skel), y, x);
N      = numel(idx);

% build adjacency neighborhood
s = []; t = [];
for i = 1:N
    nbrs = [y(i)-1 x(i)-1; y(i)-1 x(i); y(i)-1 x(i)+1;
            y(i)   x(i)-1;               y(i)   x(i)+1;
            y(i)+1 x(i)-1; y(i)+1 x(i); y(i)+1 x(i)+1];
    % keep only those inside the image
    valid = nbrs(:,1)>=1 & nbrs(:,1)<=size(skel,1) & ...
            nbrs(:,2)>=1 & nbrs(:,2)<=size(skel,2);
    nbrs = nbrs(valid,:);
    % convert to linear indices 
    nbrIdx = sub2ind(size(skel), nbrs(:,1), nbrs(:,2));
    maskInIdx = ismember(nbrIdx, idx);
    nbrIdx = nbrIdx(maskInIdx);
    jList   = arrayfun(@(v) find(idx==v,1), nbrIdx);
    % add edges
    s = [s; repmat(i,numel(jList),1)];
    t = [t; jList(:)];
end

G = graph(s, t); 

% 5) find which nodes are endpoints
endLinIdx = sub2ind(size(skel), yE, xE);
endNodeIdx = arrayfun(@(v)find(idx==v,1), endLinIdx);

% 6) pick the two endpoints with largest Euclidean separation
epX = x(endNodeIdx);
epY = y(endNodeIdx);

%    build the pairwise Euclidean‐distance matrix
D_euc = squareform( pdist([epX(:), epY(:)]) );

%    find the index of the max 
[~, lin] = max(D_euc(:));
[a, b]   = ind2sub(size(D_euc), lin);

%    map back to your graph‐node IDs
nodeA = endNodeIdx(a);
nodeB = endNodeIdx(b);

% 7) trace the curved centerline 
pathNodes = shortestpath(G, nodeA, nodeB);
xPath = x(pathNodes);
yPath = y(pathNodes);
sz = size(ROImask);

%  extend backward from the first point 
d = [ xPath(2)-xPath(1), yPath(2)-yPath(1) ]; 
u = d / norm(d);
pt = [xPath(1), yPath(1)];
extStart = [];
while true
    pt = pt - u;  
    ix = round(pt(1));  iy = round(pt(2));
    if ix<1 || ix>sz(2) || iy<1 || iy>sz(1) || ~ROImask(iy,ix)
        break;
    end
    extStart(end+1,:) = pt;  
end

%  extend forward from the last point 
d = [ xPath(end)-xPath(end-1), yPath(end)-yPath(end-1) ];
u = d / norm(d);
pt = [xPath(end), yPath(end)];
extEnd = [];
while true
    pt = pt + u;  
    ix = round(pt(1));  iy = round(pt(2));
    if ix<1 || ix>sz(2) || iy<1 || iy>sz(1) || ~ROImask(iy,ix)
        break;
    end
    extEnd(end+1,:) = pt;    
end
extStart_r=flip(extStart);
extEnd_r=flip(extEnd);

% combine into a single path 
xFull = [ extStart_r(:,1); xPath; extEnd(:,1) ];
yFull = [ extStart_r(:,2); yPath; extEnd(:,2) ];

% 8) sample intensities along that curve
nPts = numel(xFull);
vals = improfile(I, xFull, yFull, nPts);
% make a double copy for interpolation
I2 = double(I);

% distance‐to‐edge map 
D = bwdist(~ROImask);
nPts  = numel(xFull);
means = nan(nPts,1);

for i = 1:nPts
    cx = xFull(i);  cy = yFull(i);
    iy = round(cy); ix = round(cx);
    maxW = floor(D(iy,ix));
    wi   = min(w, maxW);
    if i==1
        dvec = [xFull(2)-xFull(1),       yFull(2)-yFull(1)];
    elseif i==nPts
        dvec = [xFull(end)-xFull(end-1), yFull(end)-yFull(end-1)];
    else
        dvec = [xFull(i+1)-xFull(i-1),   yFull(i+1)-yFull(i-1)];
    end
    tvec = dvec/norm(dvec);
    perp = [-tvec(2); tvec(1)];

    if wi <= 1
        % too narrow: just take the center pixel
        means(i) = I(iy,ix);
    else
        % endpoints of the cross‐section
        p1 = [cx; cy] + wi*perp;
        p2 = [cx; cy] - wi*perp;
        M  = 2*wi + 1;  % number of samples
        xs = linspace(p1(1), p2(1), M);
        ys = linspace(p1(2), p2(2), M);
        vals_line = interp2(I2, xs, ys, 'linear', NaN);
        means(i) = nanmean(vals_line);
    end
end

  diffs = hypot(diff(xFull), diff(yFull));
    arclen = [0; cumsum(diffs)];
% 9) Store results for this ROI
    centerlines{kk}    = [xFull, yFull];   
    arclengths{kk}     = round(arclen);           
    intensityPlots{kk} = means;            
end
% 10) plot to verify ---
figure; imshow(I,[]); hold on
for tt=1:kk
    position=centerlines{tt};
plot(position(:,1),position(:,2), 'r-', 'LineWidth', 2);
end
title('Curved major axis extended to true tips')


figure;
for tt=1:kk
arc=arclengths{tt};
intensity=intensityPlots{tt};
plot(arc, intensity, 'LineWidth', 2);
hold on
end
xlabel('Distance along axis (px)');
ylabel('Width‐averaged intensity');

title('Cross‐sectional mean intensity');
grid on;