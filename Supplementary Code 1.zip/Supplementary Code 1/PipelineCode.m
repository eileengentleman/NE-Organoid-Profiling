% Top-level script: measures the width-averaged fluorescence intensity along
% the curved major axis of one or more objects (e.g. organoids) in a 2-D
% microscopy image.
%
% Workflow
%   1. Load the image and convert it to a single channel.
%   2. Let the user trace one freehand region of interest (ROI) per object.
%   3. For each ROI, trace the object's curved major axis and average the
%      image intensity over cross-sections perpendicular to that axis.
%   4. Display the ROI masks and the resulting intensity profiles.
%
%   Author:  Dora <Shiyue Liu> 
%   Contact: <doraliusy@gmail.com>

% Add this folder and all of its subfolders to the MATLAB search path, so
% that MaskROI_multiple and Majorline_intensity can be called by name.
addpath(genpath(pwd))

%% input image
% Read the image to be analysed. the file must be in the current working directory (or on the path).
I = imread('organoid.png');
if size(I,3)==3,  I = rgb2gray(I);  end

%% draw ROI
[roiMasks]=MaskROI_multiple(I);

%% line width
% Upper bound, in pixels, for the HALF-width of the cross-section over which
% the intensity is averaged at each point of the major axis. The value
% actually used at each point is the smaller of w and the local distance from
% the axis to the ROI boundary, so a deliberately large value such as 1000
% means "average over the full local width of the object". Reduce w to
% restrict the averaging to a narrow band around the axis.
w=1000;

%% calcultae intensity
[I,means,positions]=Majorline_intensity(I,w,roiMasks);

%% plot mask and mean intensity
for i=1:size(roiMasks,2)
figure
imagesc(roiMasks{i});
figure
plot(means{i});
end
