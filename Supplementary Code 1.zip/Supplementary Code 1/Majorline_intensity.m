function [I2,intensityPlots,arclengths]=Majorline_intensity(I,w,roiMasks)
%MAJORLINE_INTENSITY  Width-averaged intensity along the curved major axis of each ROI.
%   INPUTS
%     I         2-D grayscale image 
%     W         Upper bound, in pixels, on the HALF-width of the averaging
%               cross-section. The value used at each point is
%               min(W, distance from that point to the ROI boundary), so a
%               large W means "average over the full local width".
%     ROIMASKS  Cell array of logical masks, one per ROI, each the same size
%               as I. Typically the output of MaskROI_multiple.
%
%   OUTPUTS
%     I2              Double-precision copy of I, made for interpolation.
%     INTENSITYPLOTS  Cell array, one entry per ROI: the width-averaged
%                     intensity profile as a column vector.
%     ARCLENGTHS      Cell array, one entry per ROI: cumulative distance
%                     along the axis, in whole pixels, starting at 0. This is
%                     the x-axis that goes with the corresponding profile..
%
%   REQUIREMENTS
%     Image Processing Toolbox (bwskel, bwmorph, bwdist, improfile, imshow)
%     and Statistics and Machine Learning Toolbox (pdist, squareform,
%     nanmean). MATLAB R2018a or newer (bwskel).
%
%   Author:  Dora <Shiyue Liu> 
%   Contact: <doraliusy@gmail.com>

numROIs          = numel(roiMasks);
centerlines      = cell(numROIs,1);    % will hold [xFull, yFull] for each ROI
arclengths       = cell(numROIs,1);    % will hold a column vector of cumulative arclength per ROI
intensityPlots   = cell(numROIs,1);    % will hold the width‐averaged intensity profile for each ROI

% =====================================================================
% Main loop: one iteration per region of interest.
% =====================================================================
% 1) skeletonize binary image
for kk=1:numROIs
    ROImask=roiMasks{kk};
skel = bwskel(ROImask,'MinBranchLength',0);

% 2) isolate the skeleton of this ROI
%    Restrict the skeleton to the current mask.
skel = skel & ROImask;

% 3) find endpoints of the skeleton
%    Endpoints are skeleton pixels with exactly one skeleton neighbour, i.e.
%    the free ends of the medial axis. [yE, xE] are their row/column indices.
endPts = bwmorph(skel,'endpoints');
[yE, xE] = find(endPts);
if numel(yE) < 2
    % A skeleton with fewer than two free ends (for example a closed loop, or
    % a region too small or too round to have a major axis) has no
    % well-defined tip-to-tip path, so this ROI is reported and skipped.
    warning('ROI %d has fewer than 2 skeleton endpoints (found %d).', kk, numel(yE));
    continue;
end
% 4) get all skeleton pixels and build a graph
%    y, x are the row/column coordinates of every skeleton pixel; idx holds
%    the corresponding linear indices; N is the number of graph nodes. Node
%    number i therefore corresponds to skeleton pixel (y(i), x(i)).
[y, x] = find(skel);
idx    = sub2ind(size(skel), y, x);
N      = numel(idx);

% build adjacency neighborhood
%   s and t accumulate the endpoints of every graph edge: edge e joins node
%   s(e) to node t(e).
s = []; t = [];
for i = 1:N
    % The eight pixels surrounding skeleton pixel i, as [row, col] pairs.
    nbrs = [y(i)-1 x(i)-1; y(i)-1 x(i); y(i)-1 x(i)+1;
            y(i)   x(i)-1;               y(i)   x(i)+1;
            y(i)+1 x(i)-1; y(i)+1 x(i); y(i)+1 x(i)+1];
    % keep only those inside the image
    valid = nbrs(:,1)>=1 & nbrs(:,1)<=size(skel,1) & ...
            nbrs(:,2)>=1 & nbrs(:,2)<=size(skel,2);
    nbrs = nbrs(valid,:);
    % convert to linear indices
    nbrIdx = sub2ind(size(skel), nbrs(:,1), nbrs(:,2));
    % Of the in-bounds neighbours, keep the ones that are themselves
    % skeleton pixels; these are the true graph neighbours of node i.
    maskInIdx = ismember(nbrIdx, idx);
    nbrIdx = nbrIdx(maskInIdx);
    % Translate those pixels back into node numbers.
    jList   = arrayfun(@(v) find(idx==v,1), nbrIdx);
    % add edges
    %   One edge from node i to each of its neighbours. Every edge is added
    %   twice (once from each end), which graph() collapses automatically.
    s = [s; repmat(i,numel(jList),1)];
    t = [t; jList(:)];
end

% Undirected graph of the skeleton. Edges are unweighted, so shortest paths
% are measured in number of pixel steps.
G = graph(s, t);

% 5) find which nodes are endpoints
%    Map the endpoint pixels found in step 3 onto their graph node numbers.
endLinIdx = sub2ind(size(skel), yE, xE);
endNodeIdx = arrayfun(@(v)find(idx==v,1), endLinIdx);

% 6) pick the two endpoints with largest Euclidean separation
%    Coordinates of the candidate endpoints.
epX = x(endNodeIdx);
epY = y(endNodeIdx);

%    build the pairwise Euclidean‐distance matrix
%    D_euc(p,q) is the straight-line distance between endpoints p and q.
D_euc = squareform( pdist([epX(:), epY(:)]) );

%    find the index of the max
%    The most widely separated pair defines the object's long direction.
[~, lin] = max(D_euc(:));
[a, b]   = ind2sub(size(D_euc), lin);

%    map back to your graph‐node IDs
nodeA = endNodeIdx(a);
nodeB = endNodeIdx(b);

% 7) trace the curved centerline
%    The shortest path through the skeleton between those two endpoints
%    follows the object's curvature, unlike a straight major axis.
pathNodes = shortestpath(G, nodeA, nodeB);
xPath = x(pathNodes);
yPath = y(pathNodes);
sz = size(ROImask);

%  extend backward from the first point
%    d is the direction from the second path point towards the first, i.e.
%    pointing outwards; u is that direction normalised to a one-pixel step.
d = [ xPath(2)-xPath(1), yPath(2)-yPath(1) ];
u = d / norm(d);
pt = [xPath(1), yPath(1)];
extStart = [];
while true
    % Step one pixel further out and test the nearest pixel: stop as soon as
    % the walk leaves the image or the ROI.
    pt = pt - u;
    ix = round(pt(1));  iy = round(pt(2));
    if ix<1 || ix>sz(2) || iy<1 || iy>sz(1) || ~ROImask(iy,ix)
        break;
    end
    % Still inside: record this sub-pixel point and continue.
    extStart(end+1,:) = pt;
end

%  extend forward from the last point
%    Same procedure at the other end of the path.
d = [ xPath(end)-xPath(end-1), yPath(end)-yPath(end-1) ];
u = d / norm(d);
pt = [xPath(end), yPath(end)];
extEnd = [];
while true
    pt = pt + u;
    ix = round(pt(1));  iy = round(pt(2));
    if ix<1 || ix>sz(2) || iy<1 || iy>sz(1) || ~ROImask(iy,ix)
        break;
    end
    extEnd(end+1,:) = pt;
end
% The backward walk was recorded outwards, so reverse it to run inwards and
% meet the start of the skeleton path.
extStart_r=flip(extStart);
extEnd_r=flip(extEnd);

% combine into a single path
%   head extension + skeleton path + tail extension, giving one continuous
%   tip-to-tip curve.
xFull = [ extStart_r(:,1); xPath; extEnd(:,1) ];
yFull = [ extStart_r(:,2); yPath; extEnd(:,2) ];

% 8) sample intensities along that curve
%    Raw intensity exactly on the centreline, one sample per axis point.
nPts = numel(xFull);
vals = improfile(I, xFull, yFull, nPts);
I2 = double(I);

% distance‐to‐edge map
D = bwdist(~ROImask);
nPts  = numel(xFull);
means = nan(nPts,1);

% Walk along the axis and average across the object at every point.
for i = 1:nPts
    % Centre of this cross-section, and the pixel it falls in.
    cx = xFull(i);  cy = yFull(i);
    iy = round(cy); ix = round(cx);
    % Widest half-section that still fits inside the ROI here, capped by the
    % user-requested half-width w.
    maxW = floor(D(iy,ix));
    wi   = min(w, maxW);
    % Local direction of the axis: central difference in the interior,
    % one-sided at the two ends.
    if i==1
        dvec = [xFull(2)-xFull(1),       yFull(2)-yFull(1)];
    elseif i==nPts
        dvec = [xFull(end)-xFull(end-1), yFull(end)-yFull(end-1)];
    else
        dvec = [xFull(i+1)-xFull(i-1),   yFull(i+1)-yFull(i-1)];
    end
    % Unit tangent, and the unit normal obtained by rotating it 90 degrees.
    tvec = dvec/norm(dvec);
    perp = [-tvec(2); tvec(1)];

    if wi <= 1
        % too narrow: just take the center pixel
        means(i) = I(iy,ix);
    else
        % endpoints of the cross‐section
        %   p1 and p2 lie wi pixels either side of the centre, along perp.
        p1 = [cx; cy] + wi*perp;
        p2 = [cx; cy] - wi*perp;
        M  = 2*wi + 1;  % number of samples
        % Evenly spaced sample coordinates from p1 to p2, one per pixel of
        % width, then bilinear interpolation of the image at those points.
        xs = linspace(p1(1), p2(1), M);
        ys = linspace(p1(2), p2(2), M);
        vals_line = interp2(I2, xs, ys, 'linear', NaN);
        % Samples that fell outside the image return NaN and are ignored.
        means(i) = nanmean(vals_line);
    end
end

  % 9) Cumulative arc length: distance travelled along the axis from its
  %    start, used as the x-axis of the intensity profile.
  diffs = hypot(diff(xFull), diff(yFull));
    arclen = [0; cumsum(diffs)];
% 9) Store results for this ROI
    centerlines{kk}    = [xFull, yFull];   
    arclengths{kk}     = round(arclen);   
    intensityPlots{kk} = means;           
end

% =====================================================================
% 10) plot to verify ---
% =====================================================================
% Overlay every extracted axis on the image. The curves should follow the
% long direction of each object and reach both of its tips.
figure; imshow(I,[]); hold on
for tt=1:kk
    position=centerlines{tt};
plot(position(:,1),position(:,2), 'r-', 'LineWidth', 2);
end
title('Curved major axis extended to true tips')

figure;
for tt=1:kk
arc=arclengths{tt};
intensity=intensityPlots{tt};
plot(arc, intensity, 'LineWidth', 2);
hold on
end
xlabel('Distance along axis (px)');
ylabel('Width‐averaged intensity');

title('Cross‐sectional mean intensity');
grid on;
