function [roiMasks] = MaskROI_multiple(image)
%MASKROI_MULTIPLE  Interactively draw one or more freehand ROIs on an image.

%   INPUT
%     IMAGE  2-D grayscale image (any numeric class).
%
%   OUTPUT
%     ROIMASKS  1-by-K cell array of logical masks, each the same size as
%               IMAGE and true inside the corresponding ROI. This is the
%               input expected by Majorline_intensity.
%
%   REQUIREMENTS
%     Image Processing Toolbox (imfreehand, createMask). Note that imfreehand
%     is deprecated by MathWorks in favour of drawfreehand; it still works in
%     current releases but may be removed in future ones.
%
%   Author:  Dora <Shiyue Liu> 
%   Contact: <doraliusy@gmail.com>

    figure;
    imagesc(image);
    axis image off;

    % Blocking message box: execution pauses here until the user dismisses
    % it, so the instructions are read before the first trace begins.
    uiwait(msgbox('Draw a region with left‐button'));

    hold on;
    roiHandles = {};    %cell array of imfreehand handles
    roiMasks   = {};    %cell array of binary masks
    roiPos     = {};    %cell array of [x,y] vertex lists

    % Index of the ROI currently being collected.
    count = 1;
    while true
        % 1) draw a freehand ROI
        %    imfreehand blocks until the mouse button is released; getPosition
        %    returns the traced contour as an N-by-2 list of [x, y] vertices.
        h = imfreehand;
        pos  = getPosition(h);

        % 2) Ask if we should keep or discard it
        choice = questdlg('Keep this ROI?','Confirm ROI','Yes','No','Yes');
        if strcmp(choice,'No')
            % User chose to delete it immediately:
            % remove the outline from the figure so it is not counted...
            delete(h);
            % go back and let them redraw
            % ...and restart the loop without incrementing count.
            continue;
        end

        % 3) Otherwise, store the handle & its mask/position
        %    createMask rasterises the freehand contour into a logical image
        %    the same size as the displayed image: true inside the ROI.
        mask = createMask(h);
        roiHandles{count} = h;       % handle, kept so the outline stays drawn
        roiMasks  {count} = mask;    % logical mask -> returned to the caller
        roiPos    {count} = pos;     % raw trace, kept for reference

        % 4) Ask whether to draw another one
        another = questdlg('Draw another ROI?','Multiple ROIs','Yes','No','Yes');
        if strcmp(another,'No')
            break;
        end

        % Move on to the next ROI slot.
        count = count + 1;
    end

    % Release the axes; the accepted ROI outlines remain visible in the
    % figure, which is a convenient record of what was measured.
    hold off;
end
